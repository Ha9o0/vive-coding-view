# /// script
# dependencies = [
#     "pygame-ce",
# ]
# ///
"""웹(브라우저) 실행용 진입점 (pygbag).
원본 프로젝트는 ../neuron_project 에 그대로 있고, 이 폴더는 웹 공개용 사본이다.
웹에서는 시작을 빠르게 하려고 numpy를 쓰지 않는다 (뉴런맵 계산은 viewer.py에서 순수 파이썬으로).
빌드:  python -m pygbag --ume_block 0 --build neuron_web   ->  neuron_web/build/web 폴더를 GitHub Pages에 올림
로컬 확인:  python -m pygbag --ume_block 0 neuron_web   ->  브라우저에서 http://localhost:8000"""
import asyncio

import viewer

asyncio.run(viewer.main())
