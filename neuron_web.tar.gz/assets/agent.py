﻿import random
import math
from collections import deque

class World:
    def __init__(self, size=10):
        self.size = size
        self.objects = []     # 현재 존재하는 Obj 목록 (Vision이 그대로 읽음)
        self.respawns = []    # [남은 스텝, Obj] 재생성 대기 목록
        self.agents = []      # 재생성 위치 충돌 확인용 (Agent가 스스로 등록)

    def add(self, obj):
        self.objects.append(obj)

    def add_walls(self, color="회색", shape="네모난"):
        """맵 가장자리(격자 경계 -0.5 ~ size-0.5)에 곧은 선분 벽 4개를 세움"""
        lo, hi = -0.5, self.size - 0.5

        for x1, y1, x2, y2 in ((lo, lo, hi, lo), (hi, lo, hi, hi), (hi, hi, lo, hi), (lo, hi, lo, lo)):
            self.add(Wall(x1, y1, x2, y2, color, shape))

    def in_bounds(self, cell):
        return 0 <= cell[0] <= self.size - 1 and 0 <= cell[1] <= self.size - 1

    def free_cells(self):
        taken = {(o.x, o.y) for o in self.objects}

        return [
            (x, y)
            for x in range(self.size)
            for y in range(self.size)
            if (x, y) not in taken
            and all(math.hypot(x - a.pos[0], y - a.pos[1]) >= 1.5 for a in self.agents)
        ]

    def consume(self, obj):
        if(obj in self.objects):
            self.objects.remove(obj)

            if(obj.respawn > 0):
                self.respawns.append([obj.respawn, obj])

    def tick(self):
        for entry in self.respawns[:]:
            entry[0] -= 1

            if(entry[0] > 0):
                continue

            obj = entry[1]
            old = (obj.x, obj.y)
            cells = [c for c in self.free_cells() if c != old]

            if(not cells):
                continue   # 자리가 없으면 다음 스텝에 다시 시도

            obj.x, obj.y = random.choice(cells)
            self.respawns.remove(entry)
            self.objects.append(obj)

    def front_object(self, pos, heading, reach):
        """몸 정면 직선상에서 표면 거리 reach 이내에 닿는 가장 가까운 객체 (없으면 None)"""
        return cast_dist(pos[0], pos[1], heading, self.objects, reach)[0]

    def clear_distance(self, pos, heading, max_dist, margin=0.0):
        """pos에서 heading 방향 직선상에 가장 먼저 닿는 객체 표면까지의 거리. 없으면 max_dist"""
        dx, dy = math.cos(math.radians(heading)), math.sin(math.radians(heading))
        best = max_dist

        for o in self.objects:
            t = o.ray_hit(pos[0], pos[1], dx, dy, margin)

            if(t is not None and 0 <= t < best):
                best = t

        return best

class Agent:
    TURN_ANGLES = (10, 20, 40)   # 회전 운동 뉴런의 각도 (방향마다 하나씩: 좌회전10, 우회전10, ...)
    MOVE_STEP = 0.5     # 전진 한 번에 이동하는 거리 (칸 단위)
    BODY_R = 0.3        # 몸 반지름 (충돌 판정)
    MOVE_COST = 0.15    # 전진 시 추가 포만도 감소 (이동 거리가 절반이 되어 값도 절반)
    FRONT_MARGIN = 0.0   # 정면 판정에서 객체 반지름에 더할 여유 (0이면 중심선만, 몸 폭까지 보려면 BODY_R)

    MOUTH = ["먹기"]
    TURN = [f"좌회전{a}" for a in TURN_ANGLES] + [f"우회전{a}" for a in TURN_ANGLES]   # 이 중 가장 강한 하나만 실행
    MOVE = ["전진"] + TURN
    HUNGRY_BELOW = 80
    BASE_COST = 0.5    # 매 스텝 포만도 감소
    EAT_REACH = 0.7        # 입이 닿는 거리 (칸 단위, 정면과 앞쪽 대각선 포함)
    TIE_MARGIN = 0.02       # 막전위 차이가 이 이하면 동점으로 보고 무작위 선택
    LOG_FILE = "brain_activity.log"
    LOG_CONSOLE = False

    def __init__(self, world, brain):
        self.world = world
        self.brain = brain
        self.vision = Vision()
        self.pos = (7.0, 7.0)
        self.heading = 0.0    # 도 단위, 0도 = 오른쪽, 시계 방향으로 증가
        self.satiety = 60.0
        self.taste_tokens = []    # 먹은 스텝에만 입력되는 미각
        self.fed_event = False    # 먹어서 포만도가 오른 스텝 표시
        self.last_ctx = {}
        self.last_fired = {}
        self.last_actions = []
        self.last_why = {}
        self.last_move = None   # 직전 이동 채널 행동
        self.steps = 0
        self.overrides = []
        self.fire_history = deque(maxlen=6)
        self.stat = {"empty": 0, "motor_fired": 0, "reward": 0}
        self.last_eat = ""
        world.agents.append(self)

        # 운동 뉴런은 몸과 함께 처음부터 존재 (실행해 본 적이 없어도 자발적으로 발화할 수 있게)
        for token in self.MOVE + self.MOUTH:
            brain.get_or_create(brain.MOTOR, token)

    # ---------------------------------
    # 감각
    # ---------------------------------

    def sense(self):
        x, y = self.pos
        seen, rates = self.vision.see(x, y, self.heading, self.world.objects)
        ctx = {
            "vision": seen,
            "taste": self.taste_tokens,
            "touch": self.body_tokens(),
            "rates": rates,   # 시각 토큰별 발화 세기 (가까울수록 큼)
        }

        # 미각과 배부름은 일어난 스텝에만 입력
        self.taste_tokens = []
        self.fed_event = False

        return ctx

    def body_tokens(self):
        tokens = []

        if(self.satiety < self.HUNGRY_BELOW):
            tokens.append("배고픔")   # 기준 미만일 때만 계속 입력

        if(self.fed_event):
            tokens.append("배부름")   # 먹어서 포만도가 오른 스텝에만 입력

        if(self.world.front_object(self.pos, self.heading, self.EAT_REACH) is not None):
            tokens.append("입닿음")   # 입이 닿는 거리(정면) 안에 무언가 있을 때만 입력 (무엇인지는 알려주지 않음)

        return tokens

    # ---------------------------------
    # 행동 선택: 채널별로 막전위가 가장 큰 운동 뉴런 하나
    # ---------------------------------

    def choose_action(self, fired):
        self.overrides = []

        def best(names):
            hits = {n: fired[n] for n in names if n in fired}

            if(not hits):
                return None

            top = max(hits.values())
            tied = [n for n, v in hits.items() if v >= top - self.TIE_MARGIN]
            return self.last_move if self.last_move in tied else random.choice(tied)

        # 발화한 운동 뉴런이 없으면 그 채널은 아무것도 하지 않음 (가만히 있음)
        # 회전(좌/우 중 강한 쪽 하나)과 전진은 함께 발화할 수 있음.
        # 함께 발화하면 회전을 먼저 실행하고 바뀐 방향으로 전진 (act는 목록 순서대로 실행)
        actions = []
        turn = best(self.TURN)
        self.last_move = turn

        if(turn):
            actions.append(turn)

        if("전진" in fired):
            actions.append("전진")

        mouth = best(self.MOUTH)

        if(mouth):
            actions.append(mouth)

        return actions
    # ---------------------------------
    # 행동 실행
    # ---------------------------------

    def act(self, actions):
        # 먹을 대상은 행동을 시작하는 시점의 자세로 정함 (같은 스텝의 이동과 동시에 일어나는 행동)
        eat_target = None

        if("먹기" in actions):
            eat_target, self.last_eat = self.find_food()

        moved = False

        for a in actions:
            if(a.startswith("좌회전")):
                self.turn(-1, int(a[3:]))

            elif(a.startswith("우회전")):
                self.turn(+1, int(a[3:]))

            elif(a == "전진"):
                step = self.forward_step()

                if(step > 0):
                    rad = math.radians(self.heading)
                    self.pos = (self.pos[0] + step * math.cos(rad),
                                self.pos[1] + step * math.sin(rad))
                    moved = True

        if("먹기" in actions):
            self.eat(eat_target)

        cost = self.BASE_COST + (self.MOVE_COST if moved else 0.0)
        self.satiety = max(0.0, self.satiety - cost)

    def eat(self, target):
        if(target is None):
            return

        self.taste_tokens = [target.taste]

        if(target.nutrition > 0):
            before = self.satiety
            self.satiety = min(100.0, self.satiety + target.nutrition)
            self.fed_event = self.satiety > before
            self.world.consume(target)
            self.last_eat += " -> 먹음"
        else:
            self.last_eat += " -> 먹을 수 없음(영양 0)"

    # ---------------------------------
    # 한 스텝
    # ---------------------------------

    def step(self):
        ctx = self.sense()
        result = self.brain.probe(**ctx)
        fired = result["motors"]
        actions = self.choose_action(fired)
        self.steps += 1

        if(not any(ctx.values())):
            self.stat["empty"] += 1

        if("배부름" in ctx["touch"]):
            self.stat["reward"] += 1

        if(fired):
            self.stat["motor_fired"] += 1
            self.fire_history.append(f"[{self.steps}] " + ", ".join(fired))
            self.log_activity(ctx, result, actions)

        self.brain.input(**ctx, motor=actions)
        self.brain.start(save=False)
        self.act(actions)
        if("먹기" in fired):
            self.emit(f"[스텝 {self.steps}] 먹기 판정: {self.last_eat}\n")
        self.world.tick()

        self.last_ctx, self.last_fired, self.last_actions = ctx, fired, actions
        self.last_why = result.get("why", {})

    def forward_step(self):
        """정면 직선에 객체가 없거나 충분히 멀면 전진할 수 있는 거리를 반환. 막혔으면 0"""
        t = self.world.clear_distance(
            self.pos, self.heading, self.MOVE_STEP + self.BODY_R, self.FRONT_MARGIN)

        step = min(self.MOVE_STEP, t - self.BODY_R)   # 몸 앞끝이 객체 표면에 닿기 직전까지

        if(step <= 0.01):
            return 0.0

        rad = math.radians(self.heading)
        nx = self.pos[0] + step * math.cos(rad)
        ny = self.pos[1] + step * math.sin(rad)

        return step if self.world.in_bounds((nx, ny)) else 0.0

    def turn(self, d, angle):
        """d: -1 좌회전, +1 우회전. angle: 발화한 회전 운동 뉴런이 맡은 각도"""
        self.heading = (self.heading + d * angle) % 360

    def log_activity(self, ctx, result, actions):
        fired = result["motors"]
        lines = [
            f"[스텝 {self.steps}] 위치 ({self.pos[0]:.1f}, {self.pos[1]:.1f}) 방향 {self.heading:.0f}도 포만도 {self.satiety:.1f}",
            f"  입력 시각 {ctx['vision']} / 미각 {ctx['taste']} / 촉각 {ctx['touch']}",
            "  뇌 발화: " + ", ".join(f"{k}({v:.2f})" for k, v in fired.items()),
            f"  실행: {actions}" + (f"  ※ 덮어씀: {self.overrides}" if self.overrides else ""),
        ]

        patterns = result.get("patterns", [])

        if(patterns):
            lines.append("  개념 발화: " + " / ".join("+".join(p["components"]) for p in patterns[:3]))

        for token, text in result.get("why", {}).items():
            lines.append(f"  [{token}의 근거]")
            lines.extend("    " + t for t in text.split("\n"))

        out = "\n".join(lines)

        with open(self.LOG_FILE, "w", encoding="utf-8") as f:
            f.write(out + "\n\n")

        if(self.LOG_CONSOLE):
            print(out + "\n")

    def find_food(self):
        """먹을 대상(정면 직선의 첫 객체)과 판정 결과 문구를 반환"""
        target = self.world.front_object(self.pos, self.heading, self.EAT_REACH)

        if(target is not None):
            return target, f"대상 {target.color} {target.taste}"

        far = self.vision.max_dist
        t = self.world.clear_distance(self.pos, self.heading, far)

        if(t < far):
            return None, f"실패: 정면 객체가 멈 (표면 거리 {t:.2f}, 허용 {self.EAT_REACH} 이내)"

        nearest = min((o for o in self.world.objects if not isinstance(o, Wall)),
                    key=lambda o: math.hypot(o.x - self.pos[0], o.y - self.pos[1]),
                    default=None)

        if(nearest is None):
            return None, "실패: 객체 없음"

        diff = (math.degrees(math.atan2(nearest.y - self.pos[1], nearest.x - self.pos[0]))
                - self.heading + 180) % 360 - 180

        return None, f"실패: 정면 직선에 객체 없음 (가장 가까운 객체는 정면에서 {diff:+.0f}도 벗어남)"

    def emit(self, text):
        with open(self.LOG_FILE, "a", encoding="utf-8") as f:
            f.write(text + "\n")

        if(self.LOG_CONSOLE):
            print(text)

class Obj:
    def __init__(self, x, y, r, color, shape, taste="무맛", nutrition=0, respawn=0):
        self.x, self.y, self.r = x, y, r
        self.color, self.shape = color, shape
        self.taste = taste            # 예: "단맛", "무맛"
        self.nutrition = nutrition    # 0이면 먹어도 포만도가 오르지 않음
        self.respawn = respawn        # 먹힌 뒤 재생성까지의 스텝 (0이면 재생성 없음)

    def ray_hit(self, ox, oy, dx, dy, margin=0.0):
        """(ox, oy)에서 방향 (dx, dy)로 쏜 직선이 원 표면에 닿는 거리. 안 닿으면 None"""
        fx, fy = ox - self.x, oy - self.y
        r = self.r + margin
        b = fx * dx + fy * dy
        disc = b * b - (fx * fx + fy * fy - r * r)

        if(disc < 0):
            return None

        return -b - math.sqrt(disc)

class Wall:
    """곧은 선분 벽. 먹을 수 없고(영양 0) 재생성되지 않는다."""

    def __init__(self, x1, y1, x2, y2, color="회색", shape="네모난", taste="무맛"):
        self.x1, self.y1, self.x2, self.y2 = x1, y1, x2, y2
        self.color, self.shape = color, shape
        self.taste = taste
        self.nutrition = 0
        self.respawn = 0
        self.x, self.y = None, None   # 격자 칸을 차지하지 않음 (재생성 위치 계산에서 제외)

    def ray_hit(self, ox, oy, dx, dy, margin=0.0):
        """(ox, oy)에서 방향 (dx, dy)로 쏜 직선이 선분에 닿는 거리. 안 닿으면 None"""
        ex, ey = self.x2 - self.x1, self.y2 - self.y1
        denom = dx * ey - dy * ex

        if(abs(denom) < 1e-12):
            return None   # 벽과 평행

        wx, wy = self.x1 - ox, self.y1 - oy
        t = (wx * ey - wy * ex) / denom   # 직선 위 거리
        s = (wx * dy - wy * dx) / denom   # 선분 위 위치 (0~1이면 선분 안)

        if(not 0 <= s <= 1):
            return None

        return t - margin

def cast_dist(ox, oy, deg, objs, max_dist):
    """ray 하나를 쏴서 (가장 가까이 닿은 객체, 거리)를 반환. 없으면 (None, max_dist)"""
    dx, dy = math.cos(math.radians(deg)), math.sin(math.radians(deg))
    best, best_t = None, max_dist

    for o in objs:
        t = o.ray_hit(ox, oy, dx, dy)

        if(t is not None and 0 <= t <= best_t):
            best, best_t = o, t

    return best, best_t


def cast(ox, oy, deg, objs, max_dist):
    return cast_dist(ox, oy, deg, objs, max_dist)[0]

class Vision:
    """망막처럼 ray마다 맡은 시야 위치가 있고, 닿은 객체의 색을 위치별로 따로 전달한다.
    모양은 따로 주지 않는다 (여러 ray에 걸친 동시 발화 묶음이 개념 뉴런으로 만들어짐).
    거리는 토큰이 아니라 세기(rate)로 전달한다: 가까울수록 1에 가깝고, 멀수록 작다."""

    RAY_LABELS = [f"좌{i}" for i in range(10, 0, -1)] + [f"우{i}" for i in range(1, 11)]   # 왼쪽부터 (좌10 ... 좌1, 우1 ... 우10)
    MIN_RATE = 0.1   # 시야 끝에 겨우 닿은 객체의 세기
    RATE_POWER = 1.0   # 1보다 크면 가까운 객체의 세기가 먼 객체보다 훨씬 커짐

    def __init__(self, half_fov=90, max_dist=8.0):
        self.half_fov = half_fov
        self.max_dist = max_dist
        self.last_rays = []   # [(각도, 거리, 닿은 객체 또는 None)] viewer 표시용

    def ray_angles(self, heading):
        n = len(self.RAY_LABELS)
        return [heading - self.half_fov + 2 * self.half_fov * i / (n - 1) for i in range(n)]

    def see(self, x, y, heading, objs):
        """반환: (토큰 목록, {토큰: 세기})  예) ["좌1:빨간", "우1:빨간"], {"좌1:빨간": 0.82, ...}"""
        tokens, rates, self.last_rays = [], {}, []

        for label, deg in zip(self.RAY_LABELS, self.ray_angles(heading)):
            o, d = cast_dist(x, y, deg, objs, self.max_dist)
            self.last_rays.append((deg, d, o))

            if(o is None):
                continue

            token = f"{label}:{o.color}"
            tokens.append(token)
            rates[token] = max(self.MIN_RATE, (1.0 - d / self.max_dist) ** self.RATE_POWER)

        return tokens, rates