class Neuron:

    # =====================================
    # 상태
    # =====================================

    RESTING = 0
    DEPOLARIZING = 1
    FIRING = 2
    REFRACTORY = 3

    # =====================================
    # 뉴런
    # =====================================

    def __init__(self,neuron_id,sense_id=None):
        self.id = neuron_id

        # 감각계 ID
        # 0 = 시각
        # 1 = 청각
        # 2 = 후각
        # 3 = 미각
        # 4 = 촉각
        #
        # 패턴 뉴런은 None
        self.sense_id = sense_id
        # 뉴런의 토큰
        self.token = None
        # 패턴 뉴런 여부
        self.is_pattern = False
        # 패턴 뉴런의 하위 뉴런
        self.pattern_children = []
        # 패턴 뉴런의 발화 기준 비율
        self.pattern_ratio = 0.7
        # 현재 상태
        self.state = self.RESTING
        # 막전위
        self.membrane_potential = 0.0
        # 일반 뉴런의 임계값
        self.threshold = 1.0
        # 이번 Tick에 들어온 신호
        self.dendrite_input = []
        # 출력 시냅스
        self.synapses = {}
        # 이번 Tick에 발화했는지
        self.fired = False
        # 발화 세기 (발화 빈도에 해당. 시냅스로 전달되는 신호 = 가중치 × 세기)
        self.rate = 1.0

    # =====================================

    def add_synapse(self,target_id):
        if(target_id not in self.synapses):
            self.synapses[target_id] = Synapse(target_id)

    # =====================================

    def update(self):
        # 매 Tick마다 초기화
        self.fired = False

        # 입력을 막전위에 반영
        if(self.dendrite_input):
            self.membrane_potential += sum(self.dendrite_input)
            self.dendrite_input.clear()

        # ---------------------------------
        # 휴지 상태
        # ---------------------------------

        if(self.state == self.RESTING and self.membrane_potential >= self.threshold):
            self.state = self.DEPOLARIZING

        # ---------------------------------
        # 탈분극
        # ---------------------------------

        elif(self.state == self.DEPOLARIZING):
            self.state = self.FIRING
            self.fired = True

        # ---------------------------------
        # 발화 후 불응기
        # ---------------------------------

        elif(self.state == self.REFRACTORY):
            self.state = self.RESTING
            self.membrane_potential = 0.0

        # ---------------------------------
        # 불응기 종료
        # ---------------------------------

        elif(self.state == self.REFRACTORY):
            self.state = self.RESTING
            self.membrane_potential = 0.0
            self.received.clear()

    # =====================================
    def receive(self,signal,source=None):
        self.dendrite_input.append(signal)

    def fire(self,neurons):
        for synapse in self.synapses.values():
            target = neurons[synapse.target_id]

            if(target.is_pattern):
                continue   # 개념 뉴런의 발화 판정은 Brain이 따로 하므로 신호를 쌓지 않음

            target.receive(synapse.weight * self.rate, self.id)

# =========================================
# 시냅스
# =========================================

class Synapse:

    # 가중치 최소/최대 한계
    MIN_WEIGHT = 0.1
    MAX_WEIGHT = 3.0

    def __init__(self,target_id):
        self.target_id = target_id
        self.weight = 1.0
        self.trace = 0.0

    # =====================================

    def transmit(self,target_neuron,source_id=None):
        target_neuron.receive(self.weight,source_id)

    # =====================================
    # 가중치 강화
    # =====================================

    def strengthen(self,amount):
        self.weight = min(self.weight + amount,self.MAX_WEIGHT)

    # =====================================
    # 가중치 약화
    # =====================================

    def weaken(self,amount):
        self.weight = max(self.weight - amount,self.MIN_WEIGHT)