﻿
import copy
import json
import random
from neuron import Neuron

class Brain:

    MAX_TICK = 4
    PATTERN_RATIO = 0.6

    # 패턴 뉴런 시냅스 실시간 학습 설정
    LEARNING_RATE = 2
    DECAY_RATE = 0.01
    
    CHILD_PRUNE_RATIO = 0.2   # 하위 뉴런의 평균 몫(총량/하위 수) 대비 이 비율 이하가 되면 패턴에서 제외
    PATTERN_BUDGET = 3.0   # 패턴 하나가 하위 시냅스에 나눠 줄 수 있는 가중치 총량
    PATTERN_LEARNING_RATE = 0.25   # 패턴 하위 시냅스 강화량 (총량 3.0 기준)
    MOTOR = 5
    REWARD_TOKENS = {"배부름"}   # 촉각(4번)에서 이 토큰이 발화하면 강화 신호 방출
    REWARD_GAIN = 0.5
    TRACE_DECAY = 0.85
    MOTOR_INIT_WEIGHT = 1   # 새로 생긴 감각 -> 운동 시냅스의 초기 가중치
    MOTOR_DECAY = 0.002        # 쓰이지 않는 운동 시냅스의 느린 약화
    PRIME_COUNT = 3       # 최근 배부름 발화가 이 횟수 이상 누적되면 증폭 상태 시작
    PRIME_WINDOW = 200    # 증폭 상태가 유지되는 스텝 수
    PRIME_MULT = 2.0      # 증폭 상태에서 강화 세기에 곱하는 배수
    COUNT_DECAY = 0.98    # 배부름 누적 횟수가 스텝마다 줄어드는 비율
    MOTOR_THRESHOLD = 1.5     # 운동 뉴런의 발화 문턱 (여러 근거가 모이거나 강하게 학습돼야 발화)
    MOTOR_USE_DECAY = 0.03    # 같이 발화했지만 보상이 없을 때 약해지는 양
    SPONT_NOISE = 1.3         # 운동 뉴런 막전위의 자발적 흔들림 (표준편차)
    PERSIST_GAIN = 0.8        # 직전에 실행한 운동 뉴런이 다음 스텝에 받는 자기 흥분
    MOUTH_TOKENS = {"먹기"}    # 섭취 행동 운동 뉴런 (자발적 활동이 작음)
    MOUTH_SPONT_NOISE = 0.5   # 섭취 행동 운동 뉴런의 자발적 흔들림 (이동보다 작게)
    MOUTH_PERSIST_GAIN = 0.0  # 섭취 행동 운동 뉴런의 자기 흥분 (헛물기가 이어지지 않게)
    PATTERN_MOTOR_INIT_WEIGHT = 1.0   # 새로 생긴 개념 -> 운동 시냅스의 초기 가중치
    PATTERN_WINNERS = 3       # 측면 억제: 한 스텝에 발화할 수 있는 개념 뉴런 수
    PATTERN_MISS_DECAY = 0.005    # 하위는 발화했지만 개념이 발화 못 했을 때, 발화한 하위 시냅스의 약화량
    PATTERN_IDLE_DECAY = 0.0002   # 개념이 발화하지 않은 스텝마다 하위 시냅스 전체의 약화량 (퇴화)

    # ===================================

    def __init__(self):
        self.neurons = {}

        # =================================
        # 감각별 토큰맵
        # =================================

        self.token_maps = {
            0: {},  # 시각
            1: {},  # 청각
            2: {},  # 후각
            3: {},  # 미각
            4: {},  # 촉각
            5: {}   # 운동
        }

        # 다음 뉴런 ID
        self.next_id = 0

        # =================================
        # 현재 입력
        # =================================

        self.vision = []
        self.hearing = []
        self.smell = []
        self.taste = []
        self.touch = []
        self.motor = []

        # =================================
        self.last_result = {"senses": [], "patterns": [], "motors": {}}
        self.reward_count = 0.0
        self.priming_left = 0
        self.running = False
        self.traced = set()   # 흔적이 남아 있는 운동 시냅스
        self.last_motor = set()   # 직전 스텝에 실행된 운동 토큰 (자기 흥분 대상)
        self.rates = {}           # 이번 입력의 토큰별 발화 세기
        self.current_motors = []  # 이번 입력에서 실행된 행동의 운동 뉴런

    # ===================================
    # 발화 결과를 웹 화면 등에서 쓸 수 있는
    # 구조화된 형태로 변환
    # ===================================

    def update_all_pattern_ratios(self):
        for neuron in self.neurons.values():
            if(not neuron.is_pattern):
                continue

            neuron.pattern_ratio = self.PATTERN_RATIO

            total_weight = sum(
                self.neurons[cid].synapses[neuron.id].weight
                for cid in neuron.pattern_children
                if neuron.id in self.neurons[cid].synapses
            )

            neuron.threshold = total_weight * neuron.pattern_ratio

    def build_result_data(self,room,fired_ids):
        fired_senses, fired_patterns, fired_motors = [], [], {}

        for neuron_id in fired_ids:
            neuron = room.get(neuron_id)

            if(neuron is None):
                continue

            if(neuron.is_pattern):
                fired_patterns.append({
                    "token": neuron.token,
                    "components": self.collect_tokens(neuron,room),
                    "threshold": neuron.threshold,
                    "membrane_potential": neuron.membrane_potential
                })
            elif(neuron.sense_id == 5):
                fired_motors[neuron.token] = neuron.membrane_potential
            else:
                fired_senses.append(neuron.token)

        return {"senses": fired_senses, "patterns": fired_patterns, "motors": fired_motors}
    # ===================================
    # 뉴런 생성
    # ===================================

    def create_neuron(self,token=None,sense_id=None):
        neuron = Neuron(self.next_id,sense_id=sense_id)
        neuron.token = token
        if(sense_id == self.MOTOR):
            neuron.threshold = self.MOTOR_THRESHOLD
        self.neurons[neuron.id] = neuron
        self.next_id += 1

        return neuron

    # ===================================
    # 감각 뉴런 가져오기 / 생성
    # ===================================

    def get_or_create(self, sense_id, token):
        token_maps = self.token_maps[sense_id]

        # 이미 존재
        if(token in token_maps):
            return self.neurons[token_maps[token]]

        # 새 뉴런
        neuron = self.create_neuron(token=token,sense_id=sense_id)
        token_maps[token] = neuron.id
        return neuron

    # ===================================
    # 시냅스 연결
    # ===================================

    def connect(self,source,target):
        is_new = target.id not in source.synapses
        source.add_synapse(target.id)

        if(is_new and target.sense_id == self.MOTOR):
            source.synapses[target.id].weight = self.MOTOR_INIT_WEIGHT
    # ===================================
    # 입력
    # ===================================

    def input(self, vision=None, hearing=None, smell=None, taste=None, touch=None, motor=None, rates=None):
        self.rates = {} if rates is None else rates   # 토큰별 발화 세기 (없으면 1.0)
        self.vision = [] if vision is None else vision
        self.hearing = [] if hearing is None else hearing
        self.smell = [] if smell is None else smell
        self.taste = [] if taste is None else taste
        self.touch = [] if touch is None else touch
        self.motor = [] if motor is None else motor

# ===================================
# 유사한 기존 패턴 탐색
# (하위 뉴런이 부족하거나 많아도
# 발화 비율 기준으로 판단)
# ===================================

    def find_matching_pattern(self,activated):
        activated_ids = set(neuron.id for neuron in activated)
        levels = self.pattern_levels()
        # 이 묶음으로 만들어질 층 = 하위 중 가장 높은 층 + 1. 같은 층의 개념하고만 비교
        # (그래야 1층 + 2층 묶음이 기존 2층에 흡수되지 않고 3층 이상이 생길 수 있음)
        target_level = 1 + max((levels.get(n.id, 1) if n.is_pattern else 0) for n in activated)

        best_pattern = None
        best_ratio = 0.0

        for pattern in self.neurons.values():
            if(not pattern.is_pattern or levels.get(pattern.id) != target_level):
                continue

            total_weight = 0.0
            matched_weight = 0.0

            for child_id in pattern.pattern_children:
                child = self.neurons.get(child_id)

                if(child is None or pattern.id not in child.synapses):
                    continue

                weight = child.synapses[pattern.id].weight
                total_weight += weight

                if(child.id in activated_ids):
                    matched_weight += weight

            if(total_weight <= 0):
                continue

            ratio = matched_weight / total_weight

            # 발화 기준 비율 이상 겹치면 같은 개념으로 간주
            if(ratio >= pattern.pattern_ratio and ratio > best_ratio):
                best_ratio = ratio
                best_pattern = pattern

        return best_pattern
    # ===================================
    # 유사 패턴에 새로운 하위 뉴런을 편입
    # ===================================

    def pattern_levels(self):
        """개념 뉴런의 층: 하위 중 가장 높은 층 + 1 (감각 뉴런 = 0층). {개념 id: 층}
        개념의 하위 구성이 바뀔 때만 다시 계산 (levels_dirty)"""
        if(not getattr(self, "levels_dirty", True) and getattr(self, "levels_cache", None) is not None):
            return self.levels_cache

        memo = {}

        def level(nid):
            n = self.neurons.get(nid)

            if(n is None or not n.is_pattern):
                return 0

            if(nid not in memo):
                memo[nid] = 1   # 계산 중 표시 (순환이 있어도 무한 반복하지 않게)
                memo[nid] = 1 + max((level(c) for c in n.pattern_children), default=0)

            return memo[nid]

        for nid, n in self.neurons.items():
            if(n.is_pattern):
                level(nid)

        self.levels_cache, self.levels_dirty = memo, False
        return memo

    def merge_into_pattern(self,pattern,activated):
        levels = self.pattern_levels()
        my_level = levels.get(pattern.id, 1)

        for neuron in activated:
            # 자기 자신이나 같은/더 높은 층의 개념은 하위로 받지 않음 (A -> B -> A 같은 순환 방지)
            if(neuron.id == pattern.id or (neuron.is_pattern and levels.get(neuron.id, 1) >= my_level)):
                continue

            if(neuron.id not in pattern.pattern_children):
                pattern.pattern_children.append(neuron.id)
                self.levels_dirty = True   # 개념 구성이 바뀜 -> 층 다시 계산

            if(pattern.id not in neuron.synapses):
                neuron.add_synapse(pattern.id)

        self.normalize_pattern(pattern)

    # ===================================
    # 패턴 뉴런 생성
    # ===================================

    def create_pattern_neuron(self, activated):

        # ---------------------------------
        # 유사한 기존 패턴이 있으면 재사용 + 편입
        # ---------------------------------

        existing = self.find_matching_pattern(activated)

        if(existing is not None):
            self.merge_into_pattern(existing,activated)
            return existing

        # ---------------------------------
        # 유사 패턴이 없으면 새 패턴 뉴런 생성
        # ---------------------------------

        pattern = self.create_neuron(token=f"N{self.next_id}",sense_id=None)
        pattern.is_pattern = True
        pattern.pattern_ratio = self.PATTERN_RATIO
        pattern.pattern_children = [neuron.id for neuron in activated]
        self.levels_dirty = True   # 개념 구성이 바뀜 -> 층 다시 계산

        for neuron in activated:
            self.connect(neuron,pattern)

        self.normalize_pattern(pattern)
        return pattern
    
    # ===================================
    # 판단 시작
    # ===================================

    def start(self, save=True):
        self.last_motor = set(self.motor)   # 이번 스텝에 실행한 행동 = 다음 스텝 자기 흥분 대상

        if(not self.has_input()):
            return

        self.running = True

        activated = self.process_input()

        sensory = [n for n in activated if n.sense_id != self.MOTOR]

        if(len(sensory) >= 2):
            self.create_pattern_neuron(sensory)

        # 자격 흔적과 증폭 상태 감쇠
        self.decay_traces()
        self.reward_count *= self.COUNT_DECAY

        if(self.priming_left > 0):
            self.priming_left -= 1

        # 보상 신호: 이번 스텝의 태깅보다 먼저, 전체 뉴런맵에 방송
        if(any(token in self.REWARD_TOKENS for token in self.touch)):
            self.reward_count += 1.0

            if(self.reward_count >= self.PRIME_COUNT):
                self.priming_left = self.PRIME_WINDOW

            mult = self.PRIME_MULT if self.priming_left > 0 else 1.0
            self.modulate(self.REWARD_GAIN * mult)

        fired_ids = set()
        self.session_fired_tick = {}

        try:
            for tick in range(1,self.MAX_TICK + 1):
                if(not self.running):
                    break

                self.process_tick(tick)

                for neuron in self.neurons.values():
                    if(neuron.fired):
                        fired_ids.add(neuron.id)

            self.last_fired_ids = set(fired_ids)
            self.last_result = self.build_result_data(self.neurons,fired_ids)

            # 같은 층에서 함께 발화한 개념 뉴런 2개 이상으로 바로 위층 개념을 만든다 (감각 -> 1층과 같은 규칙, 층 수 제한 없음)
            # 다른 층끼리는 묶지 않음: 새로 생긴 맨 위층 개념 하나가 매 스텝 층을 하나씩 쌓는 것을 막음
            levels = self.pattern_levels()
            fired_by_level = {}

            for n in self.neurons.values():
                if(n.is_pattern and n.id in fired_ids):
                    fired_by_level.setdefault(levels.get(n.id, 1), []).append(n)

            for level in sorted(fired_by_level):
                if(len(fired_by_level[level]) >= 2):
                    self.create_pattern_neuron(fired_by_level[level])

            # 이번 스텝에 한 번도 발화하지 않은 개념: 하위 시냅스 전체가 서서히 약해짐 (쓰이지 않는 개념의 퇴화)
            for pattern in self.neurons.values():
                if(not pattern.is_pattern or pattern.id in fired_ids):
                    continue

                for cid in pattern.pattern_children:
                    child = self.neurons.get(cid)

                    if(child is not None and pattern.id in child.synapses):
                        synapse = child.synapses[pattern.id]
                        synapse.weight = max(0.0, synapse.weight - self.PATTERN_IDLE_DECAY)

        finally:
            # 한 번의 입력 = 한 번의 완결된 순환을 보장
            self.reset_neuron_states(self.neurons)
            self.clear_input()

            if(save):
                self.save("network.json")

            self.running = False

    def probe(self, **tokens):
        """학습 없이 현재 입력에 대한 운동 뉴런의 반응만 계산 (뇌를 복사하지 않음)"""
        keys = {"vision": 0, "hearing": 1, "smell": 2, "taste": 3, "touch": 4}
        rates = tokens.get("rates") or {}
        active = {}    # 이번 입력으로 발화할 뉴런 id -> 발화 세기

        for key, sid in keys.items():
            for token in tokens.get(key) or []:
                nid = self.token_maps[sid].get(token)

                if(nid in self.neurons):
                    active[nid] = rates.get(token, 1.0)

        # 개념 뉴런: 아래층부터 차례로, 하위 발화 비율이 기준 이상인 후보 중 층마다 가장 잘 맞는 몇 개만 발화
        # (update_pattern_neurons의 측면 억제와 같은 기준)
        by_level = {}

        for pid, level in self.pattern_levels().items():
            by_level.setdefault(level, []).append(self.neurons[pid])

        for level in sorted(by_level):
            candidates = []

            for pattern in by_level[level]:
                total, hit = 0.0, 0.0

                for cid in pattern.pattern_children:
                    child = self.neurons.get(cid)

                    if(child is None or pattern.id not in child.synapses):
                        continue

                    w = child.synapses[pattern.id].weight
                    total += w

                    if(cid in active):
                        hit += w

                if(total > 0 and hit >= total * pattern.pattern_ratio):
                    candidates.append((hit / total, len(pattern.pattern_children), pattern.id))

            candidates.sort(reverse=True)

            for _, _, pid in candidates[:self.PATTERN_WINNERS]:
                active[pid] = 1.0

        sources = {}   # 운동 뉴런 id -> [(입력 뉴런, 가중치 × 발화 세기)]

        for nid, rate in active.items():
            neuron = self.neurons[nid]

            for target_id, synapse in neuron.synapses.items():
                target = self.neurons.get(target_id)

                if(target is not None and target.sense_id == self.MOTOR):
                    sources.setdefault(target_id, []).append((neuron, synapse.weight * rate))

        motors, why = {}, {}

        # 모든 운동 뉴런: 감각 입력 + 자발적 막전위 흔들림 + 직전 실행에 따른 자기 흥분
        for motor_id in self.token_maps[self.MOTOR].values():
            motor = self.neurons[motor_id]
            srcs = sources.get(motor_id, [])
            # 섭취 행동(먹기)은 이동과 달리 자발적으로는 거의 일어나지 않고 자극에 의해 일어남
            is_mouth = motor.token in self.MOUTH_TOKENS
            spont = random.gauss(0.0, self.MOUTH_SPONT_NOISE if is_mouth else self.SPONT_NOISE)
            gain = self.MOUTH_PERSIST_GAIN if is_mouth else self.PERSIST_GAIN
            persist = gain if motor.token in self.last_motor else 0.0
            total = sum(w for _, w in srcs) + spont + persist

            if(total >= motor.threshold):
                motors[motor.token] = total
                lines = [motor.token]

                for neuron, w in sorted(srcs, key=lambda s: -s[1]):
                    lines.append(f"  └ {neuron.token} ({w:.2f})")
                    lines.append("    └ 입력 (1.00)")

                lines.append(f"  └ 자발적 활동 ({spont:+.2f})")

                if(persist):
                    lines.append(f"  └ 직전 실행의 자기 흥분 ({persist:.2f})")

                why[motor.token] = "\n".join(lines)

        return {"senses": [], "patterns": [], "motors": motors, "why": why}
    # ===================================
    # 입력 존재 여부
    # ===================================

    def has_input(self):

        return bool(
            self.vision
            or
            self.hearing
            or
            self.smell
            or
            self.taste
            or
            self.touch
            or
            self.motor
        )

    # ===================================
    # 입력 처리
    # ===================================

    def process_input(self):

        sense_inputs = {

            0: self.vision,
            1: self.hearing,
            2: self.smell,
            3: self.taste,
            4: self.touch,
            5: self.motor
        }

        activated = []

        # =================================
        # 감각별 입력 처리
        # =================================

        for sense_id,tokens in sense_inputs.items():
            for token in tokens:
                if(token == ""):
                    continue

                neuron = self.get_or_create(sense_id,token)
                neuron.receive(neuron.threshold)   # 실제로 실행한 운동 뉴런은 문턱만큼 활성 (감각 뉴런은 문턱이 1.0이라 기존과 같음)
                neuron.rate = self.rates.get(token, 1.0)   # 발화 세기 (시각은 가까울수록 큼)
                activated.append(neuron)

        self.current_motors = [n for n in activated if n.sense_id == self.MOTOR]

        # =================================
        # 같은 입력 안에서 동시 입력된
        # 뉴런끼리 연결
        # =================================

        for i in range(len(activated)):
            for j in range(i + 1,len(activated)):
                source = activated[i]
                target = activated[j]
                self.connect(source,target)

        return activated

    # ===================================
    # Tick 진행
    # ===================================

    def process_tick(self,tick_number):

        # =================================
        # 1.
        # 일반 뉴런 업데이트
        # =================================

        for neuron in list(self.neurons.values()):
            if(neuron.is_pattern):
                continue

            neuron.update()

        # =================================
        # 2.
        # 일반 뉴런 발화 확인 + 발화 tick 기록
        # =================================

        fired_neurons = []

        for neuron in list(self.neurons.values()):
            if(neuron.is_pattern):
                continue

            if(neuron.fired):
                fired_neurons.append(neuron)

                if(neuron.id not in self.session_fired_tick):
                    self.session_fired_tick[neuron.id] = tick_number

        # =================================
        # 3.
        # 일반 뉴런 → 시냅스 전달
        # =================================

        for neuron in fired_neurons:
            neuron.fire(self.neurons)

        # =================================
        # 4.
        # 동시입력(일반 뉴런 간) 시냅스 학습
        # =================================

        if(fired_neurons):
            earliest = min(self.session_fired_tick.values())
            direct = [n for n in fired_neurons if self.session_fired_tick[n.id] == earliest]

            if(direct):
                self.update_sense_synapses(direct)
        # =================================
        # 5.
        # 패턴 뉴런 판단
        # =================================

        self.update_pattern_neurons(tick_number)


    # ===================================
    # 세션 종료 시 이번 방(room)에 있던
    # 모든 일반 뉴런을 초기 상태로 리셋
    # (한 번의 입력 = 한 번의 완결된 순환을 보장)
    # ===================================

    def reset_neuron_states(self,room):
        for neuron in room.values():
            if(neuron.is_pattern):
                continue

            neuron.state = Neuron.RESTING
            neuron.membrane_potential = 0.0
            neuron.dendrite_input.clear()
            neuron.fired = False
            neuron.rate = 1.0
    # ===================================
    # 패턴 뉴런 판단
    # ===================================

    def update_pattern_neurons(self, tick_number=None):
        dying_patterns = []

        # ---------------------------------
        # 이번 세션에서 가장 먼저 발화가
        # 일어난 tick (직접 입력의 기준 tick)
        # ---------------------------------

        if(self.session_fired_tick):
            earliest_fire_tick = min(self.session_fired_tick.values())
        else:
            earliest_fire_tick = None

        # 개념은 감각이 직접 입력으로 처음 발화한 tick에만 발화할 수 있으므로 그 tick에만 판단 (계산 절약)
        if(earliest_fire_tick is None or (tick_number is not None and tick_number != earliest_fire_tick)):
            return

        # ---------------------------------
        # 1~2단계를 아래층부터 층마다 반복 (층 수 제한 없음):
        # 1단계: 문턱을 넘은 개념 뉴런(후보) 찾기
        # 2단계: 측면 억제 - 그 층에서 가장 잘 맞는 개념 뉴런 몇 개만 발화
        #        (일치 비율이 높고, 같으면 하위 뉴런이 많은 = 더 구체적인 개념이 이김)
        # 아래층에서 발화한 개념은 바로 위층 개념의 하위 입력이 된다
        # ---------------------------------

        touched = []      # 하위 뉴런이 하나라도 발화한 개념: (패턴, 발화한 하위 뉴런)
        by_level = {}

        for pid, level in self.pattern_levels().items():
            by_level.setdefault(level, []).append(self.neurons[pid])

        for level in sorted(by_level):
            candidates = []   # (일치 비율, 하위 수, 패턴, 발화 가중치, 관여한 하위 뉴런)

            for pattern in by_level[level]:
                total_weight = 0.0
                fired_weight = 0.0
                fired_children = []

                for child_id in pattern.pattern_children:
                    child = self.neurons.get(child_id)

                    if(child is None or pattern.id not in child.synapses):
                        continue

                    synapse = child.synapses[pattern.id]
                    total_weight += synapse.weight

                    if(child.is_pattern):
                        # 하위 개념: 이번 판단에서 아래층이 발화시켰으면 관여
                        fired_directly = child.fired
                    else:
                        # 감각: 발화했고, 그 시점이 이번 세션의 가장 이른 발화 tick과 같을 때
                        fired_directly = (
                            child.fired and
                            self.session_fired_tick.get(child.id) == earliest_fire_tick
                        )

                    if(fired_directly):
                        fired_weight += synapse.weight
                        fired_children.append(child)

                pattern.threshold = total_weight * pattern.pattern_ratio
                pattern.fired = False

                if(fired_children):
                    touched.append((pattern, fired_children))

                if(total_weight > 0 and fired_weight >= pattern.threshold):
                    candidates.append((fired_weight / total_weight, len(pattern.pattern_children),
                                       pattern, fired_weight, fired_children))

            candidates.sort(key=lambda c: (c[0], c[1]), reverse=True)

            for _, _, pattern, fired_weight, fired_children in candidates[:self.PATTERN_WINNERS]:
                pattern.state = Neuron.FIRING
                pattern.fired = True
                pattern.membrane_potential = fired_weight
                pattern.fire(self.neurons)

                for child in fired_children:
                    child.synapses[pattern.id].strengthen(self.PATTERN_LEARNING_RATE)

                self.normalize_pattern(pattern)
                self.update_pattern_motor_synapses(pattern)

        # 하위 뉴런은 발화했는데 개념은 발화하지 못한 경우 (문턱 미달 또는 측면 억제에서 짐):
        # 그 개념에서 발화한 하위 뉴런의 시냅스만 약화
        for pattern, fired_children in touched:
            if(pattern.fired):
                continue

            for child in fired_children:
                synapse = child.synapses[pattern.id]
                synapse.weight = max(0.0, synapse.weight - self.PATTERN_MISS_DECAY)

        # ---------------------------------
        # 3단계: 약해진 하위 뉴런 제외, 하위가 부족한 개념 삭제
        # ---------------------------------

        for pattern in list(self.neurons.values()):
            if(not pattern.is_pattern):
                continue

            # 하위 뉴런이 많을수록 한 개당 몫이 작아지므로 제외 기준도 함께 낮아진다
            prune_at = self.CHILD_PRUNE_RATIO * self.PATTERN_BUDGET / max(len(pattern.pattern_children), 1)

            weak_children = [
                cid for cid in pattern.pattern_children
                if cid in self.neurons
                and pattern.id in self.neurons[cid].synapses
                and self.neurons[cid].synapses[pattern.id].weight <= prune_at
            ]

            for cid in weak_children:
                del self.neurons[cid].synapses[pattern.id]
                pattern.pattern_children.remove(cid)
                self.levels_dirty = True   # 개념 구성이 바뀜 -> 층 다시 계산

            # 패턴은 하위 뉴런이 2개 이상이어야 의미가 있음
            if(len(pattern.pattern_children) < 2):
                dying_patterns.append(pattern.id)
                continue

        for pattern_id in dying_patterns:
            self.remove_pattern(pattern_id)
    # ===================================
    # 일반 뉴런끼리의 시냅스 학습
    # (같이 발화했으면 강화, 한쪽만 발화했으면 약화)
    # ===================================

    def update_sense_synapses(self,fired_neurons):
        fired_ids = set(n.id for n in fired_neurons)

        for neuron in list(self.neurons.values()):
            if(neuron.is_pattern):
                continue

            for target_id in list(neuron.synapses.keys()):
                target = self.neurons.get(target_id)

                if(target is None or target.is_pattern):
                    continue

                synapse = neuron.synapses[target_id]

                both_fired = neuron.id in fired_ids and target.id in fired_ids
                either_fired = neuron.id in fired_ids or target.id in fired_ids

                # 운동 시냅스: 같이 발화해도 가중치는 올리지 않고 흔적만 남김
                # (강화는 보상 신호 modulate()가 담당, 보상이 없으면 반복할수록 약해짐)
                if(target.sense_id == self.MOTOR):
                    if(both_fired):
                        synapse.trace = 1.0
                        self.traced.add(synapse)
                        synapse.weaken(self.MOTOR_USE_DECAY)
                    elif(either_fired):
                        synapse.weaken(self.MOTOR_DECAY)

                    continue

                if(both_fired):
                    synapse.strengthen(self.LEARNING_RATE)
                elif(either_fired):
                    synapse.weaken(self.DECAY_RATE)

    def decay_traces(self):
        for synapse in list(self.traced):
            synapse.trace *= self.TRACE_DECAY

            if(synapse.trace < 0.01):
                synapse.trace = 0.0
                self.traced.discard(synapse)

    def modulate(self,gain):
        for synapse in self.traced:
            synapse.strengthen(gain * synapse.trace)

    def update_pattern_motor_synapses(self,pattern):
        """개념 뉴런 -> 운동 뉴런: 감각 -> 운동과 같은 규칙.
        이번에 실행한 행동과 같이 발화하면 연결을 만들고 흔적을 남긴다 (강화는 보상 신호가 담당).
        같이 발화하지 않은 운동 뉴런으로의 연결은 천천히 약해진다."""
        for motor in self.current_motors:
            if(motor.id not in pattern.synapses):
                self.connect(pattern,motor)
                pattern.synapses[motor.id].weight = self.PATTERN_MOTOR_INIT_WEIGHT

        executed = set(n.id for n in self.current_motors)

        for target_id, synapse in pattern.synapses.items():
            target = self.neurons.get(target_id)

            if(target is None or target.sense_id != self.MOTOR):
                continue

            if(target_id in executed):
                synapse.trace = 1.0
                self.traced.add(synapse)
                synapse.weaken(self.MOTOR_USE_DECAY)
            else:
                synapse.weaken(self.MOTOR_DECAY)

    def normalize_pattern(self,pattern):
        syns = [
            self.neurons[cid].synapses[pattern.id]
            for cid in pattern.pattern_children
            if cid in self.neurons and pattern.id in self.neurons[cid].synapses
        ]
        total = sum(s.weight for s in syns)

        if(total > 0):
            scale = self.PATTERN_BUDGET / total

            for s in syns:
                s.weight *= scale   # MIN_WEIGHT로 막지 않아야 제외 기준이 작동

            pattern.threshold = self.PATTERN_BUDGET * pattern.pattern_ratio

    def remove_pattern(self,pattern_id):
        pattern = self.neurons.get(pattern_id)

        if(pattern is None):
            return

        # 하위 뉴런 -> 이 패턴으로의 시냅스 제거
        for child_id in pattern.pattern_children:
            child = self.neurons.get(child_id)

            if(child is not None and pattern_id in child.synapses):
                del child.synapses[pattern_id]

        # 상위 패턴이 이 패턴을 하위 요소로 참조 중이면 제거
        for neuron in self.neurons.values():
            if(neuron.is_pattern and pattern_id in neuron.pattern_children):
                neuron.pattern_children.remove(pattern_id)

        # 잔여 시냅스 제거 (안전 차원)
        for neuron in self.neurons.values():
            if(pattern_id in neuron.synapses):
                del neuron.synapses[pattern_id]

        del self.neurons[pattern_id]
        self.levels_dirty = True   # 개념 구성이 바뀜 -> 층 다시 계산

    def clear_input(self):

        self.rates = {}
        self.vision = []
        self.hearing = []
        self.smell = []
        self.taste = []
        self.touch = []
        self.motor = []

    def collect_tokens(self,neuron,room):
        if(not neuron.is_pattern):
            return [neuron.token]

        tokens = []

        for child_id in neuron.pattern_children:
            child = room.get(child_id)

            if(child is None):
                continue

            tokens.extend(self.collect_tokens(child,room))

        return tokens

    # ===================================
    # 저장
    # ===================================

    def save(self,filename):
        data = self._serialize()

        with open(filename,"w",encoding="utf-8") as f:
            json.dump(data,f,ensure_ascii=False)

    # ===================================
    # 직렬화 (save/undo 공용)
    # ===================================

    def _serialize(self):
        data = {

            "next_id":
                self.next_id,

            "neurons": [],

            "token_maps":
                self.token_maps
        }

        for neuron in self.neurons.values():
            data["neurons"].append({

                "id":
                    neuron.id,

                "sense_id":
                    neuron.sense_id,

                "token":
                    neuron.token,

                "is_pattern":
                    neuron.is_pattern,

                "pattern_children":
                    neuron.pattern_children,

                "pattern_ratio":
                    neuron.pattern_ratio,

                "state":
                    neuron.state,

                "membrane_potential":
                    neuron.membrane_potential,

                "threshold":
                    neuron.threshold,

                "synapses": [

                    {

                        "target":
                            syn.target_id,

                        "weight":
                            syn.weight
                    }

                    for syn in neuron.synapses.values()
                ]
            })

        return data

    # ===================================
# 불러온 데이터의 정합성 검사 및 자동 복구
# (수동 편집으로 인한 불일치 대비)
# ===================================

    def validate_and_repair(self):
        report = []

        # ---------------------------------
        # 1. next_id 보정
        # 실제 존재하는 최대 id보다 next_id가
        # 작거나 같으면 충돌 위험이 있으므로 올림
        # ---------------------------------

        if(self.neurons):
            max_id = max(self.neurons.keys())

            if(self.next_id <= max_id):
                report.append(
                    f"next_id 보정: {self.next_id} -> {max_id + 1}"
                )
                self.next_id = max_id + 1

        # ---------------------------------
        # 2. token_maps 재구성
        # 실제 뉴런 데이터를 기준으로 다시 만든다
        # (수동 편집으로 token_maps가 어긋나 있어도
        # neurons 배열이 진짜 출처가 되도록)
        # ---------------------------------

        rebuilt = {i: {} for i in range(6)}

        for neuron in self.neurons.values():
            if(neuron.is_pattern or neuron.sense_id is None):
                continue

            if(neuron.sense_id not in rebuilt):
                continue

            token_map = rebuilt[neuron.sense_id]

            # 같은 토큰이 이미 등록돼 있으면 더 작은 id(먼저 생성된 쪽)를 유지
            if(neuron.token in token_map):
                existing_id = token_map[neuron.token]

                if(neuron.id < existing_id):
                    token_map[neuron.token] = neuron.id
            else:
                token_map[neuron.token] = neuron.id

        if(rebuilt != self.token_maps):
            report.append("token_maps를 뉴런 데이터 기준으로 재구성함")

        self.token_maps = rebuilt

        # ---------------------------------
        # 3. 끊어진 참조 정리
        # 존재하지 않는 뉴런을 가리키는
        # pattern_children / synapses 제거
        # ---------------------------------

        for neuron in self.neurons.values():

            if(neuron.is_pattern):
                before = len(neuron.pattern_children)
                neuron.pattern_children = [
                    cid for cid in neuron.pattern_children
                    if cid in self.neurons
                ]

                if(len(neuron.pattern_children) != before):
                    report.append(
                        f"{neuron.token}: 존재하지 않는 하위 뉴런 참조 "
                        f"{before - len(neuron.pattern_children)}개 제거"
                    )

            broken_targets = [
                target_id for target_id in neuron.synapses
                if target_id not in self.neurons
            ]

            for target_id in broken_targets:
                del neuron.synapses[target_id]

            if(broken_targets):
                report.append(
                    f"{neuron.token}: 존재하지 않는 시냅스 대상 "
                    f"{len(broken_targets)}개 제거"
                )

        # ---------------------------------
        # 결과 출력
        # ---------------------------------

        if(report):
            print("[정합성 복구]")
            for line in report:
                print(f" - {line}")
        else:
            print("[정합성 검사] 이상 없음")
    # ===================================
    # 불러오기
    # ===================================

    def load(self,filename):
        with open(filename, "r", encoding="utf-8") as f:
            data = json.load(f)

        self.next_id = data["next_id"]
        self.neurons.clear()

        # =================================
        # 감각별 토큰맵 복구
        # =================================

        self.token_maps = {
            int(key): value
            for key,value in data["token_maps"].items()
            }

        # =================================
        # 뉴런 복구
        # =================================

        for n in data["neurons"]:
            neuron = Neuron(n["id"], n["sense_id"])
            neuron.token = n["token"]
            neuron.is_pattern = n.get("is_pattern", False)
            neuron.pattern_children = n.get("pattern_children", [])
            neuron.pattern_ratio = n.get("pattern_ratio", self.PATTERN_RATIO)
            neuron.state = n["state"]
            neuron.membrane_potential = n["membrane_potential"]
            neuron.threshold = n["threshold"]
            if(neuron.sense_id == self.MOTOR):
                neuron.threshold = self.MOTOR_THRESHOLD
            self.neurons[neuron.id] = neuron

        # =================================
        # 시냅스 복구
        # =================================

        for n in data["neurons"]:
            neuron = self.neurons[n["id"]]

            for s in n["synapses"]:
                neuron.add_synapse(s["target"])
                neuron.synapses[s["target"]].weight = s["weight"]

        self.validate_and_repair()

    def motor_weight_stats(self):
        ws = [
            s.weight
            for n in self.neurons.values()
            for t, s in n.synapses.items()
            if t in self.neurons and self.neurons[t].sense_id == self.MOTOR
        ]

        return (max(ws), sum(ws) / len(ws), len(ws)) if ws else (0.0, 0.0, 0)
