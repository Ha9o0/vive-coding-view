﻿import math
import os
import json
import asyncio
import random
import pygame

from brain import Brain
from agent import World, Agent, Obj, Wall, cast_dist

# =====================================
# 설정
# =====================================

NET_FILE = "network.json"
NET_LIVE = False           # True면 파일 대신 메모리의 뇌를 바로 그림 (저장 없이 실시간)
NET_REFRESH = 20           # 이 스텝마다 파일을 다시 읽음
VIEW_SAVE_EVERY = 50       # 파일 모드에서 이 스텝마다 network.json에 저장
FRAME_MS = 100             # 한 프레임 간격 (기존 FuncAnimation interval과 같음)
NET_MIN_W = 0.5            # 감각끼리의 연결은 이 가중치 이상만 그림
NET_PLAIN_MAX = 150        # 웹용: 감각끼리의 회색 연결선은 가중치가 큰 순으로 이만큼만 그림
NET_TOPK = 3               # 운동 뉴런마다 가중치가 큰 입력 연결을 이만큼만 그림
NET_LAYOUT_ITERS = 2       # 웹용: 시뮬레이션 1스텝마다 배치를 다듬는 반복 횟수 (자리 잡은 뒤에는 거의 안 움직임)
NET_NODE_GAP = 10          # 뉴런 원 사이에 남길 최소 간격 (픽셀, 이름표 자리 포함)
NET_FILL = 0.35            # 뉴런 원과 간격이 패널 면적에서 차지할 비율 (넘으면 원을 작게 그림)
NET_LABEL_MIN = 0.8        # 원 크기가 이 배율보다 작으면 발화한 뉴런과 마우스를 올린 뉴런만 이름 표시
NET_REPEL_RANGE = 2.0      # 웹용: 이 배수(× NET_SPREAD) 거리 안의 뉴런끼리만 밀어냄 (계산량 줄이기)
NET_SPREAD = 1.3          # 뉴런끼리 떨어지려는 거리 (클수록 넓게 퍼짐)
NET_SETTLE_STEP = 0.02    # 처음 배치 이후 프레임마다 뉴런이 움직일 수 있는 최대 거리 (작을수록 덜 떨림)
NET_CAMERA_DIST = 3.0      # 카메라 거리 (배치 반지름의 배수, 작을수록 원근감이 강함)
NET_FOG = 0.6              # 가장 먼 뉴런이 배경색 쪽으로 흐려지는 정도
NET_AUTO_ROTATE = 0.9      # 웹용: 마우스가 뉴런맵 밖에 있을 때 뉴런맵을 다시 그릴 때마다(초당 약 10번) 자동으로 도는 각도
NET_ROTATE_SPEED = 0.4     # 왼쪽 드래그 1픽셀당 회전 각도

WIN_W, WIN_H = 1600, 820
WALL_PX = 6                # 벽 선 두께 (픽셀)

BG = (250, 250, 250)
INK = (30, 30, 30)
QUIET = (110, 110, 110)
GRID = (225, 225, 225)
NET_BG = (30, 30, 30)

OBJ_COLORS = {"빨간": (214, 39, 40), "회색": (128, 128, 128), "노란": (255, 215, 0), "보라": (128, 0, 128)}
# 뉴런 색: 종류마다 채도가 높은 색으로 채우고, 테두리는 같은 색의 밝은 톤 (어두운 배경에서 구별이 쉽게)
#            시각 파랑        청각 청록        후각 분홍        미각 주황        촉각 초록        운동 빨강
NODE_FILL = {0: (37, 99, 235), 1: (13, 148, 136), 2: (219, 39, 119), 3: (234, 88, 12), 4: (22, 163, 74), 5: (220, 38, 38)}
NODE_EDGE = {0: (147, 197, 253), 1: (94, 234, 212), 2: (249, 168, 212), 3: (253, 186, 116), 4: (134, 239, 172), 5: (252, 165, 165)}
PATTERN_FILL, PATTERN_EDGE = (147, 51, 234), (216, 180, 254)   # 개념 보라
EDGE_PLAIN, EDGE_PATTERN, EDGE_MOTOR = (70, 70, 70), (139, 127, 214), (224, 122, 122)
FIRE_EDGE = (226, 160, 72)     # 이번 스텝 발화 경로 선 (감각 -> 개념 -> 운동)
FIRE_RIM = (214, 178, 112)     # 이번 스텝 발화한 뉴런의 테두리 (흰색보다 덜 밝게)
HOVER_EDGE = (150, 190, 235)   # 마우스를 올린 뉴런과 상·하위 뉴런을 잇는 선
KIND_NAMES = {0: "시각", 1: "청각", 2: "후각", 3: "미각", 4: "촉각", 5: "운동"}
HOVER_MAX = 8                  # 말풍선에 상·하위 뉴런을 각각 이만큼까지 표시
NET_FIRE_TOPK = 3              # 발화 경로: 운동 뉴런마다 기여가 큰 입력을 이만큼만 표시

# =====================================
# 시뮬레이션 준비 (기존 viewer.py와 동일)
# =====================================

state = {"step": 0, "paused": False, "speed": 1, "frame": 0}
history = []
net_cache = {"data": None, "step": 0}
stats_cache = {"frame": -99, "value": (0.0, 0.0, 0)}
layout = {}   # 뉴런 id -> 위치 (프레임이 바뀌어도 위치를 이어서 다듬음)

brain = Brain()
brain.verbose = False

try:
    brain.load("network.json")
    brain.update_all_pattern_ratios()
except FileNotFoundError:
    pass


def make_world():
    w = World(size=15)
    w.add(Obj(3, 5, 0.5, "빨간", "둥근", taste="단맛", nutrition=80, respawn=20))
    w.add(Obj(9, 7, 0.5, "빨간", "둥근", taste="단맛", nutrition=80, respawn=20))
    w.add(Obj(11, 12, 0.5, "빨간", "둥근", taste="단맛", nutrition=80, respawn=20))
    w.add(Obj(4, 8, 0.5, "빨간", "둥근", taste="단맛", nutrition=80, respawn=20))

    w.add(Obj(3, 4, 0.5, "회색", "네모난", taste="무맛"))
    w.add(Obj(6, 7, 0.5, "회색", "네모난", taste="무맛"))
    w.add_walls()   # 가장자리 회색 벽
    return w


world = make_world()
agent = Agent(world, brain)


def reset_episode(new_brain=False):
    global brain, world, agent

    if(new_brain):
        brain = Brain()
        brain.verbose = False
        layout.clear()
    else:
        brain.save("network.json")   # 지금까지의 학습 저장

        # 이전 에피소드의 자격 흔적이 새 에피소드로 넘어가지 않게 초기화
        for synapse in brain.traced:
            synapse.trace = 0.0

        brain.traced.clear()

        brain.reward_count = 0.0
        brain.priming_left = 0

    world = make_world()
    agent = Agent(world, brain)
    state["step"] = 0
    history.clear()
    net_cache["data"] = None


def sim_update():
    """한 프레임의 시뮬레이션 진행 (기존 viewer.py의 update()에서 그리기만 뺀 것과 동일)"""
    if(not state["paused"]):
        for _ in range(state["speed"]):
            agent.step()
            state["step"] += 1
            history.append(agent.satiety)

            if(agent.satiety <= 0):
                reset_episode(new_brain=False)   # 굶으면 네트워크는 유지한 채 처음 상태로
                break

            if(not NET_LIVE and state["step"] % VIEW_SAVE_EVERY == 0):
                brain.save(NET_FILE)

    state["frame"] += 1
    net_redraw["dirty"] = True    # 웹용: 시뮬레이션이 한 스텝 진행되면 뉴런맵을 다시 그리고 배치도 다듬음
    net_redraw["relax"] = True


net_redraw = {"dirty": True, "relax": True, "image": None}   # 웹용: 뉴런맵을 그려 두고 재사용하기 위한 상태


def motor_stats():
    if(state["frame"] - stats_cache["frame"] >= 15):
        stats_cache["value"] = brain.motor_weight_stats()
        stats_cache["frame"] = state["frame"]

    return stats_cache["value"]


def load_net():
    cached = net_cache["data"]

    if(cached is not None and 0 <= state["step"] - net_cache["step"] < NET_REFRESH):
        return cached

    try:
        if(NET_LIVE):
            data = brain._serialize()
        else:
            with open(NET_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = cached

    net_cache["data"] = data
    net_cache["step"] = state["step"]
    return data

# =====================================
# 글자 (한 번 그린 글자는 재사용)
# =====================================

def find_korean_font():
    # 웹(브라우저)에는 시스템 글꼴이 없으므로 함께 넣은 나눔고딕(SIL Open Font License)을 먼저 사용
    for path in ("NanumGothic.ttf", r"C:\Windows\Fonts\malgun.ttf", "/System/Library/Fonts/AppleSDGothicNeo.ttc",
                 "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"):
        if(os.path.exists(path)):
            return path

    return pygame.font.match_font("malgungothic,applegothic,nanumgothic")


fonts = {}
text_cache = {}


def text_img(words, size=14, color=INK, bold=False):
    key = (words, size, color, bold)
    img = text_cache.get(key)

    if(img is None):
        if((size, bold) not in fonts):
            f = pygame.font.Font(find_korean_font(), size)
            f.bold = bold
            fonts[(size, bold)] = f

        img = fonts[(size, bold)].render(words, True, color)

        if(len(text_cache) > 3000):
            text_cache.clear()

        text_cache[key] = img

    return img


def text(surface, words, pos, size=14, color=INK, bold=False, anchor="topleft"):
    img = text_img(words, size, color, bold)
    rect = img.get_rect(**{anchor: pos})
    surface.blit(img, rect)
    return rect

# =====================================
# 공간
# =====================================

def draw_world(screen, area):
    n = world.size
    pad = WALL_PX   # 벽 선 두께만큼 여유
    cell = (min(area.w, area.h - 30) - 2 * pad) / n
    ox, oy = area.x + pad, area.y + 30 + pad

    def P(x, y):
        return (ox + (x + 0.5) * cell, oy + (y + 0.5) * cell)

    status = "일시정지" if state["paused"] else "실행 중"
    text(screen, f"스텝 {state['step']} ({status}, 속도 x{state['speed']})", (ox + n * cell / 2, area.y + 4),
         size=16, anchor="midtop")

    for i in range(n + 1):
        pygame.draw.line(screen, GRID, (ox + i * cell, oy), (ox + i * cell, oy + n * cell))
        pygame.draw.line(screen, GRID, (ox, oy + i * cell), (ox + n * cell, oy + i * cell))

    for o in world.objects:
        color = OBJ_COLORS.get(o.color, (0, 0, 0))

        if(isinstance(o, Wall)):
            pygame.draw.line(screen, color, P(o.x1, o.y1), P(o.x2, o.y2), WALL_PX)
        else:
            pygame.draw.circle(screen, color, P(o.x, o.y), o.r * cell)

    x, y = agent.pos
    v = agent.vision
    h = agent.heading

    screen.set_clip(pygame.Rect(ox, oy, n * cell, n * cell))   # 시야와 ray는 공간 칸 안에서만

    # 시야 부채꼴 (반투명)
    fov = pygame.Surface((area.w, area.h), pygame.SRCALPHA)
    cx, cy = P(x, y)
    pts = [(cx - area.x, cy - area.y)]

    for k in range(25):
        a = math.radians(h - v.half_fov + 2 * v.half_fov * k / 24)
        pts.append((cx - area.x + v.max_dist * cell * math.cos(a), cy - area.y + v.max_dist * cell * math.sin(a)))

    pygame.draw.polygon(fov, (31, 119, 180, 30), pts)
    screen.blit(fov, area.topleft)

    # 시야 ray 10개: 닿은 객체가 있으면 그 지점까지 객체 색으로, 없으면 흐린 선
    # (감각 입력은 행동 전 자세 기준이라, 화면에는 지금 자세로 다시 계산해서 부채꼴과 맞춤. 뇌 입력에는 영향 없음)
    for deg in v.ray_angles(h):
        o, d = cast_dist(x, y, deg, world.objects, v.max_dist)
        a = math.radians(deg)
        end = P(x + d * math.cos(a), y + d * math.sin(a))

        if(o is None):
            pygame.draw.line(screen, (205, 205, 205), P(x, y), end, 1)
        else:
            pygame.draw.line(screen, OBJ_COLORS.get(o.color, (0, 0, 0)), P(x, y), end, 2)

    # 입이 닿는 거리 (주황)
    hr = math.radians(h)
    pygame.draw.line(screen, (255, 165, 0), P(x, y), P(x + agent.EAT_REACH * math.cos(hr), y + agent.EAT_REACH * math.sin(hr)), 4)

    # 에이전트와 몸 방향
    pygame.draw.circle(screen, (31, 119, 180), P(x, y), 0.3 * cell)
    pygame.draw.line(screen, (255, 255, 255), P(x, y), P(x + 0.5 * math.cos(hr), y + 0.5 * math.sin(hr)), 3)

    screen.set_clip(area)

# =====================================
# 시야 띠: 뇌가 받은 시각 입력을 ray 하나당 정사각형 하나로 표시
# =====================================

def draw_eye(screen, area):
    """지금 자세에서 각 ray에 잡히는 것 (= 다음 스텝에 뇌가 받을 시각 입력). 위 공간 화면의 ray와 같은 기준"""
    v = agent.vision
    labels = v.RAY_LABELS
    n = len(labels)
    x, y = agent.pos

    text(screen, "시야 (왼쪽 → 오른쪽, ray 하나당 한 칸) · 진할수록 가까움", (area.x, area.y), size=13, color=QUIET)

    gap = 0   # 칸 사이 간격 없이 붙임
    size = min((area.w - gap * (n - 1)) / n, area.h - 44)
    x0 = area.x + (area.w - (size * n + gap * (n - 1))) / 2
    y0 = area.y + 22

    for k, (label, deg) in enumerate(zip(labels, v.ray_angles(agent.heading))):
        left, right = round(x0 + k * size), round(x0 + (k + 1) * size)   # 이웃 칸과 정확히 맞닿게
        box = pygame.Rect(left, round(y0), right - left, round(size))
        o, d = cast_dist(x, y, deg, world.objects, v.max_dist)

        if(o is None):
            pygame.draw.rect(screen, (255, 255, 255), box)
        else:
            rate = max(v.MIN_RATE, (1.0 - d / v.max_dist) ** v.RATE_POWER)   # Vision.see()와 같은 계산
            base = OBJ_COLORS.get(o.color, (0, 0, 0))
            # 세기만큼 객체 색, 나머지는 흰색: 가까우면 진하고 멀면 흐림
            pygame.draw.rect(screen, tuple(round(255 + (c - 255) * rate) for c in base), box)
        text(screen, label, (box.centerx, box.bottom + 3), size=10, color=QUIET, anchor="midtop")

# =====================================
# 포만도 그래프
# =====================================

def draw_plot(screen, area):
    text(screen, "포만도 (점선 = 배고픔 기준)", (area.centerx, area.y + 4), size=16, anchor="midtop")
    box = pygame.Rect(area.x + 36, area.y + 30, area.w - 46, area.h - 56)
    pygame.draw.rect(screen, (255, 255, 255), box)
    pygame.draw.rect(screen, QUIET, box, 1)

    def Y(val):
        return box.bottom - val / 100 * box.h

    for val in (0, 20, 40, 60, 80, 100):
        text(screen, str(val), (box.x - 6, Y(val)), size=11, color=QUIET, anchor="midright")

    # 배고픔 기준 점선
    yb = Y(agent.HUNGRY_BELOW)

    for xd in range(box.x, box.right, 10):
        pygame.draw.line(screen, QUIET, (xd, yb), (min(xd + 5, box.right), yb))

    data = history[-500:]

    if(len(data) >= 2):
        pts = [(box.x + i / 499 * box.w, Y(val)) for i, val in enumerate(data)]
        pygame.draw.lines(screen, (44, 160, 44), False, pts, 2)

    text(screen, f"재생성 대기 중: {len(world.respawns)}개", (box.x + 8, box.y + 6), size=13)
    text(screen, f"강화 증폭: {'켜짐' if brain.priming_left > 0 else '꺼짐'} (남은 {brain.priming_left}스텝, 누적 {brain.reward_count:.1f})",
         (box.x + 8, box.bottom - 6), size=13, anchor="bottomleft")

# =====================================
# 상태 글자
# =====================================

def draw_text(screen, area):
    fired = ", ".join(f"{k}({v:.1f})" for k, v in agent.last_fired.items()) or "없음 (가만히 있음)"
    mx, avg, cnt = motor_stats()

    rates = agent.last_ctx.get("rates", {})
    seen = " ".join(f"{t}({rates.get(t, 1.0):.2f})" for t in agent.last_ctx.get("vision", [])) or "없음"

    lines = [
        f"포만도: {agent.satiety:.1f}",
        f"입력 시각 (세기): {seen}",
        f"입력 미각: {agent.last_ctx.get('taste', [])}   촉각: {agent.last_ctx.get('touch', [])}",
        f"뇌가 발화시킨 운동: {fired}",
        f"실행한 행동: {agent.last_actions}",
        f"먹기 판정: {agent.last_eat}",
        f"진단: 무입력 {agent.stat['empty']}/{agent.steps}, 보상 {agent.stat['reward']}회, 운동 발화 {agent.stat['motor_fired']}회",
        f"운동 시냅스 {cnt}개 (최대 {mx:.2f}, 평균 {avg:.2f}) / 문턱 {brain.MOTOR_THRESHOLD}",
        "최근 뇌 발화: " + (" / ".join(list(agent.fire_history)[-3:]) or "없음"),
        "",
        "스페이스: 일시정지 / 위·아래: 속도 / r: 다시 시작(학습 유지) / n: 학습까지 초기화",
        "뉴런맵: 휠 확대/축소, 왼쪽 드래그 회전, 오른쪽 드래그 이동, 0 원래대로",
    ]

    y = area.y

    for line in lines:
        text(screen, line, (area.x, y), size=13)
        y += 24

    for token, why in agent.last_why.items():
        if(y > area.bottom - 20):
            break

        text(screen, f"[{token}의 근거] " + "  ".join(s.strip() for s in why.split("\n")[1:3]), (area.x, y), size=13, color=QUIET)
        y += 22

# =====================================
# 뉴런맵
# =====================================

def relax_layout(ids, edges, pulls, iters):
    """3차원 힘 기반 배치: 연결된 뉴런끼리는 당기고(pulls = 연결별 당기는 세기), 가까운 뉴런끼리는 밀어낸다.
    웹용: numpy 없이 순수 파이썬으로 계산. 밀어내는 힘은 공간을 칸으로 나눠 가까운 칸의 뉴런끼리만 계산한다."""
    for i in list(layout):
        if(i not in ids):
            del layout[i]

    first = not layout

    for i in ids:
        if(i in layout):
            continue

        near = [layout[b] for a, b in edges if a == i and b in layout] + \
               [layout[a] for a, b in edges if b == i and a in layout]

        if(near):
            start = [sum(p[c] for p in near) / len(near) for c in range(3)]
        else:
            start = [random.gauss(0, 1.0) for _ in range(3)]

        layout[i] = [start[c] + random.gauss(0, 0.1) for c in range(3)]

    if(not ids):
        return

    if(first):
        iters = 300   # 처음에는 충분히 풀어 줌

    index = {i: k for k, i in enumerate(ids)}
    P = [list(layout[i]) for i in ids]
    E = [(index[a], index[b], s) for (a, b), s in zip(edges, pulls)]
    n = len(P)
    k = NET_SPREAD   # 이상적인 간선 길이 (클수록 넓게 퍼짐)
    kk = k * k
    reach = NET_REPEL_RANGE * k                   # 이 거리 안의 뉴런끼리만 밀어냄
    reach2 = reach * reach
    step = 0.08 if first else NET_SETTLE_STEP   # 한 번에 움직일 수 있는 최대 거리 (자리 잡은 뒤에는 작게)

    for _ in range(iters):
        disp = [[0.0, 0.0, 0.0] for _ in range(n)]

        # 밀어냄: reach 크기의 칸으로 공간을 나누고, 이웃한 27칸 안의 뉴런끼리만 계산
        grid = {}

        for a, p in enumerate(P):
            grid.setdefault((math.floor(p[0] / reach), math.floor(p[1] / reach), math.floor(p[2] / reach)), []).append(a)

        for (gx, gy, gz), members in grid.items():
            neigh = [b for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)
                     for b in grid.get((gx + dx, gy + dy, gz + dz), ())]

            for a in members:
                pa, da = P[a], disp[a]

                for b in neigh:
                    if(b == a):
                        continue

                    pb = P[b]
                    x, y, z = pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2]
                    d2 = x * x + y * y + z * z + 1e-6

                    if(d2 > reach2):
                        continue

                    f = kk / d2
                    da[0] += x * f
                    da[1] += y * f
                    da[2] += z * f

        # 당김: 연결된 뉴런끼리
        for a, b, s in E:
            pa, pb = P[a], P[b]
            x, y, z = pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2]
            f = (math.sqrt(x * x + y * y + z * z) + 1e-6) / k * s
            da, db = disp[a], disp[b]
            da[0] -= x * f
            da[1] -= y * f
            da[2] -= z * f
            db[0] += x * f
            db[1] += y * f
            db[2] += z * f

        for a in range(n):
            p, d = P[a], disp[a]

            for c in range(3):
                d[c] -= p[c] * 0.05   # 떨어진 무리가 멀리 흩어지지 않게 중앙으로 약하게 당김

            length = math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]) + 1e-6
            m = min(length, step) / length

            for c in range(3):
                p[c] += d[c] * m

    for i, p in zip(ids, P):
        layout[i] = p


def net_node_scale(ids, neurons, view):
    """뉴런이 많아지면 원 크기를 줄여, 원과 간격이 패널 면적의 NET_FILL 정도만 차지하게 함 (최대 1배)"""
    need = sum(((22.0 if neurons[i]["is_pattern"] else 14.0) + NET_NODE_GAP) ** 2 for i in ids)
    return min(1.0, (NET_FILL * view.w * view.h / max(need, 1.0)) ** 0.5)


def project_3d(ids, view_rect):
    """3차원 배치를 지금 회전 각도로 돌려 원근법으로 화면에 투영.
    반환: {id: (화면 x, 화면 y, 원근 배율, 깊이 0~1 (0 = 가장 가까움))}"""
    # 웹용: numpy 없이 순수 파이썬으로 계산
    pts = [layout[i] for i in ids]
    n = len(pts)
    mean = [sum(p[c] for p in pts) / n for c in range(3)]

    yaw, pitch = math.radians(net_view["yaw"]), math.radians(net_view["pitch"])
    cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
    Q = []

    for p in pts:
        x, y, z = p[0] - mean[0], p[1] - mean[1], p[2] - mean[2]
        x1, z1 = cy * x + sy * z, -sy * x + cy * z          # 세로축을 중심으로 회전 (yaw)
        Q.append((x1, cp * y - sp * z1, sp * y + cp * z1))  # 가로축을 중심으로 회전 (pitch)

    dist = [math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2]) for q in Q]
    radius = max(max(dist), 1e-6)
    cam = radius * NET_CAMERA_DIST                       # 카메라와 배치 중심 사이 거리
    # 화면 크기는 뉴런의 90%가 들어가는 범위에 맞춤 (바깥으로 튄 몇 개 때문에 전체가 작아지지 않게)
    p90 = sorted(dist)[int(0.9 * (n - 1))]
    fit = min(view_rect.w, view_rect.h) / 2 / max(p90, 1e-6) * 0.9
    zoom, (px, py) = net_view["zoom"], net_view["pan"]
    result = {}

    for i, q in zip(ids, Q):
        persp = cam / (cam + q[2])                       # 가까울수록 크게, 멀수록 작게
        result[i] = (view_rect.centerx + q[0] * fit * persp * zoom + px,
                     view_rect.centery + q[1] * fit * persp * zoom + py,
                     persp, (q[2] + radius) / (2 * radius))

    return result


def fade(color, depth, bg=NET_BG):
    """먼 뉴런·연결일수록 배경색 쪽으로 흐리게 (깊이 0 = 가까움)"""
    t = NET_FOG * depth
    return tuple(round(c + (b - c) * t) for c, b in zip(color, bg))


net_struct = {"data": None}

NET_ZOOM_MIN, NET_ZOOM_MAX = 0.3, 8.0
net_view = {"zoom": 1.0, "pan": [0.0, 0.0], "drag": None, "rotate": None, "mouse": None,
            "yaw": 0.0, "pitch": 15.0}   # 확대 배율, 이동량, 이동/회전 드래그 시작점, 마우스 위치, 회전 각도


def net_inner(area):
    return area.inflate(-60, -90).move(0, 25)


def net_zoom(mouse, factor):
    """마우스 위치를 기준으로 확대/축소 (커서 아래의 점이 제자리에 머물게)"""
    c = net_inner(AREA_NET).center
    z = net_view["zoom"]
    z2 = max(NET_ZOOM_MIN, min(NET_ZOOM_MAX, z * factor))

    for k in (0, 1):
        u = (mouse[k] - c[k] - net_view["pan"][k]) / z
        net_view["pan"][k] = mouse[k] - c[k] - u * z2

    net_view["zoom"] = z2


def build_net(data):
    """network.json에서 그릴 뉴런과 연결을 골라 둔다 (데이터가 바뀔 때만 다시 계산)"""
    neurons = {n["id"]: n for n in data["neurons"] if n["is_pattern"] or n["sense_id"] in NODE_FILL}
    pattern_edges, motor_edges, plain_edges, seen = [], [], [], set()

    for p in neurons.values():
        if(p["is_pattern"]):
            for c in p["pattern_children"]:
                if(c in neurons):
                    seen.add((min(c, p["id"]), max(c, p["id"])))
                    pattern_edges.append((c, p["id"]))

    to_motor = {}
    in_weight = {}   # (하위 뉴런, 패턴) -> 가중치

    for n in neurons.values():
        for s in n["synapses"]:
            t = s["target"]

            if(t not in neurons or n["id"] == t):
                continue

            if(neurons[t]["is_pattern"]):
                in_weight[(n["id"], t)] = s["weight"]

            key = (min(n["id"], t), max(n["id"], t))

            if(key in seen):
                continue

            if(neurons[t]["sense_id"] == 5):
                to_motor.setdefault(t, []).append((s["weight"], n["id"]))
            elif(not neurons[t]["is_pattern"] and s["weight"] >= NET_MIN_W):
                seen.add(key)
                plain_edges.append((s["weight"], key))

    # 웹용: 감각끼리의 회색 연결선은 가중치가 큰 것만 남김 (그리는 양 줄이기)
    plain_edges = [key for w, key in sorted(plain_edges, reverse=True)[:NET_PLAIN_MAX]]

    for m, srcs in to_motor.items():
        for w, src in sorted(srcs, reverse=True)[:NET_TOPK]:
            motor_edges.append((src, m))

    # 층 사이 연결: 하위 -> 상위 (감각 -> 개념 1층 -> 개념 2층 ... -> 운동). 발화 경로와 마우스 말풍선에 사용
    level = neuron_levels(neurons)
    upward = []   # (하위 id, 상위 id, 가중치)

    for n in neurons.values():
        for s in n["synapses"]:
            t = s["target"]

            if(t in neurons and level[n["id"]] < level[t]):
                upward.append((n["id"], t, s["weight"]))

    return {
        "source": data,
        "neurons": neurons,
        "ids": sorted(neurons),
        "pattern_edges": pattern_edges,
        "motor_edges": motor_edges,
        "plain_edges": plain_edges,
        "in_weight": in_weight,
        "upward": upward,
        "level": level,
    }


MOTOR_LEVEL = 10 ** 6   # 운동 뉴런은 항상 맨 위층


def neuron_levels(neurons):
    """뉴런의 층: 감각 0, 개념 = 하위 중 가장 높은 층 + 1, 운동 = 맨 위. {id: 층}"""
    memo = {}

    def level(i):
        n = neurons.get(i)

        if(n is None):
            return 0

        if(not n["is_pattern"]):
            return MOTOR_LEVEL if n["sense_id"] == 5 else 0

        if(i not in memo):
            memo[i] = 1
            memo[i] = 1 + max((level(c) for c in n["pattern_children"] if c in neurons), default=0)

        return memo[i]

    return {i: level(i) for i in neurons}


def neuron_kind(n, level=None):
    if(n["is_pattern"]):
        return f"개념 {level}층" if level else "개념"

    return KIND_NAMES.get(n["sense_id"], "?")


def draw_hover(screen, area, net, hovered, S):
    """마우스를 올린 뉴런의 상위 뉴런(이 뉴런이 신호를 보내는 쪽)과 하위 뉴런(이 뉴런에 신호를 보내는 쪽)을
    선과 말풍선으로 표시. 층은 감각 -> 개념 -> 운동 순서"""
    neurons = net["neurons"]
    upper = sorted(((w, t) for s, t, w in net["upward"] if s == hovered), reverse=True)
    lower = sorted(((w, s) for s, t, w in net["upward"] if t == hovered), reverse=True)

    for _, other in upper + lower:
        pygame.draw.line(screen, HOVER_EDGE, S(hovered), S(other), 2)

    n = neurons[hovered]
    lines = [(f"{n['token']}  ({neuron_kind(n, net['level'].get(hovered))})", (240, 240, 240), True)]

    for title, group in (("상위", upper), ("하위", lower)):
        lines.append((f"{title} {len(group)}개" + ("" if group else "  (없음)"), (190, 200, 215), False))

        for w, other in group[:HOVER_MAX]:
            o = neurons[other]
            lines.append((f"   {o['token']} ({neuron_kind(o, net['level'].get(other))})   가중치 {w:.2f}", (215, 215, 215), False))

        if(len(group) > HOVER_MAX):
            lines.append((f"   … 외 {len(group) - HOVER_MAX}개", (160, 160, 160), False))

    imgs = [text_img(words, 12, color, bold) for words, color, bold in lines]
    box = pygame.Rect(0, 0, max(img.get_width() for img in imgs) + 20, sum(img.get_height() + 3 for img in imgs) + 14)
    mx, my = net_view["mouse"]
    box.topleft = (mx + 16, my + 16)
    box.clamp_ip(area)

    pygame.draw.rect(screen, (44, 46, 54), box, border_radius=6)
    pygame.draw.rect(screen, (95, 100, 115), box, 1, border_radius=6)
    y = box.y + 7

    for img in imgs:
        screen.blit(img, (box.x + 10, y))
        y += img.get_height() + 3


def draw_network(screen, area):
    pygame.draw.rect(screen, NET_BG, area)
    data = load_net()

    if(not data or not data.get("neurons")):
        text(screen, "뉴런맵 (데이터 없음)", (area.centerx, area.y + 10), size=15, color=(230, 230, 230), anchor="midtop")
        return

    if(net_struct["data"] is None or net_struct["data"]["source"] is not data):
        net_struct["data"] = build_net(data)

    net = net_struct["data"]
    neurons, ids = net["neurons"], net["ids"]
    pe, me, se = net["pattern_edges"], net["motor_edges"], net["plain_edges"]

    view = net_inner(area)
    node_scale = net_node_scale(ids, neurons, view)
    if(net_redraw["relax"] or not layout):   # 웹용: 배치는 시뮬레이션 1스텝마다만 다듬음
        relax_layout(ids, pe + me + se, [1.0] * len(pe) + [0.6] * len(me) + [0.05] * len(se), NET_LAYOUT_ITERS)
        net_redraw["relax"] = False

    text(screen, f"뉴런맵 ({'메모리' if NET_LIVE else NET_FILE}) 뉴런 {len(neurons)}개", (area.centerx, area.y + 8),
         size=14, color=(230, 230, 230), anchor="midtop")
    text(screen, "보라 개념 · 파랑 시각 · 주황 미각 · 초록 촉각 · 빨강 운동 · 금색/주황 선 = 발화 경로",
         (area.centerx, area.y + 28), size=12, color=(180, 180, 180), anchor="midtop")
    text(screen, "마우스 올리기: 상·하위 뉴런 · 왼쪽 드래그: 회전 · 오른쪽 드래그: 이동 · 휠: 확대",
         (area.centerx, area.y + 44), size=12, color=(180, 180, 180), anchor="midtop")

    if(not ids):
        return

    # 마우스가 뉴런맵 밖에 있고 회전 중이 아니면 천천히 저절로 돌아 입체감을 보여 줌
    if(net_view["mouse"] is None and net_view["rotate"] is None):
        net_view["yaw"] = (net_view["yaw"] + NET_AUTO_ROTATE) % 360

    # 3차원 배치를 회전·원근 투영한 화면 좌표
    proj = project_3d(ids, view)
    z = net_view["zoom"]

    def S(i):
        return proj[i][0], proj[i][1]

    def depth_of(*ns):
        return sum(proj[i][3] for i in ns) / len(ns)

    # 이번 스텝에 실제로 발화한 뉴런 (뇌가 기록한 발화 결과: 감각, 측면 억제를 통과한 개념, 실행한 운동)
    lit = set(getattr(brain, "last_fired_ids", set())) & set(ids)

    # 연결선: 먼 것부터 그리고, 멀수록 흐리게
    lines = [(depth_of(x, y), x, y, color, width)
             for group, color, width in ((se, EDGE_PLAIN, 1), (me, EDGE_MOTOR, 1), (pe, EDGE_PATTERN, 2))
             for x, y in group]

    for d, x, y, color, width in sorted(lines, key=lambda l: -l[0]):
        if(width == 1):
            pygame.draw.aaline(screen, fade(color, d), S(x), S(y))
        else:
            pygame.draw.line(screen, fade(color, d), S(x), S(y), width)

    # 발화 경로: 양쪽이 모두 발화한 층 사이 연결 (감각 -> 개념, 감각/개념 -> 운동)
    # 운동 뉴런은 들어오는 신호(가중치 × 세기)가 큰 입력 몇 개만 그려서 주된 경로만 보이게 함
    rates = agent.last_ctx.get("rates", {})

    def contrib(src, w):
        n = neurons[src]
        return w * (rates.get(n["token"], 1.0) if n["sense_id"] == 0 else 1.0)

    for t in lit:
        level = net["level"][t]

        if(level == 0):
            continue

        srcs = sorted(((contrib(s, w), s) for s, tt, w in net["upward"] if tt == t and s in lit), reverse=True)

        if(level == MOTOR_LEVEL):
            srcs = srcs[:NET_FIRE_TOPK]

        for c, s in srcs:
            pygame.draw.line(screen, FIRE_EDGE, S(s), S(t), 2 if c < 1.5 else 3)

    # 마우스를 올린 뉴런 찾기
    hovered = None
    mouse = net_view["mouse"]

    if(mouse is not None):
        best = 14 ** 2

        for i in ids:
            cx, cy = S(i)
            d2 = (cx - mouse[0]) ** 2 + (cy - mouse[1]) ** 2

            if(d2 <= best):
                hovered, best = i, d2

    # 뉴런이 많으면 원을 작게 그림. 확대하면 원래 크기까지 다시 커짐
    size = min(1.0, node_scale * z)
    show_all_labels = size >= NET_LABEL_MIN   # 원이 작을 때는 이름표가 겹치므로 발화·마우스 올린 뉴런만 이름 표시

    # 먼 뉴런부터 그려서 가까운 뉴런이 앞을 가리게 함. 멀수록 작고 흐리게
    for i in sorted(ids, key=lambda i: -proj[i][3]):
        n = neurons[i]
        on = i in lit
        c = S(i)
        persp, d = proj[i][2], proj[i][3]

        if(n["is_pattern"]):
            r, face, rim = 11, PATTERN_FILL, PATTERN_EDGE
        else:
            r, face, rim = 7, NODE_FILL[n["sense_id"]], NODE_EDGE[n["sense_id"]]

        r = max(3, round(r * size * persp))

        if(on):
            r = round(r * 1.15)
            rim = FIRE_RIM

        pygame.draw.circle(screen, fade(face, d), c, r)
        pygame.draw.circle(screen, fade(rim, d), c, r, 2 if r > 4 else 1)

        if(i == hovered):
            pygame.draw.circle(screen, HOVER_EDGE, c, r + 4, 2)

        if(show_all_labels or on or i == hovered):
            text(screen, str(n["token"]), (c[0], c[1] + r + 2), size=12,
                 color=(228, 228, 228) if on else (195, 195, 195), anchor="midtop")

    if(hovered is not None):
        draw_hover(screen, area, net, hovered, S)

# =====================================
# 화면 구성
# =====================================

AREA_WORLD = pygame.Rect(16, 10, 560, 600)
AREA_PLOT = pygame.Rect(600, 10, 420, 300)
AREA_TEXT = pygame.Rect(600, 330, 420, 480)
AREA_NET = pygame.Rect(1040, 10, 548, 800)
AREA_EYE = pygame.Rect(16, 622, 560, 100)   # 공간 아래 시야 띠


def draw(screen):
    screen.fill(BG)

    # 각 패널은 자기 영역 밖으로 그려지지 않게 잘라냄
    for area, fn in ((AREA_WORLD, draw_world), (AREA_EYE, draw_eye), (AREA_PLOT, draw_plot),
                     (AREA_TEXT, draw_text)):
        screen.set_clip(area)
        fn(screen, area)

    # 웹용: 뉴런맵은 바뀌었을 때(시뮬레이션 1스텝, 마우스 조작)만 다시 그리고, 그 사이에는 그려 둔 그림을 씀
    screen.set_clip(AREA_NET)

    if(net_redraw["dirty"] or net_redraw["image"] is None):
        draw_network(screen, AREA_NET)
        net_redraw["image"] = screen.subsurface(AREA_NET).copy()
        net_redraw["dirty"] = False
    else:
        screen.blit(net_redraw["image"], AREA_NET.topleft)

    screen.set_clip(None)


def on_key(key):
    if(key == pygame.K_SPACE):
        state["paused"] = not state["paused"]
    elif(key == pygame.K_UP):
        state["speed"] = min(state["speed"] * 2, 64)
    elif(key == pygame.K_DOWN):
        state["speed"] = max(state["speed"] // 2, 1)
    elif(key == pygame.K_r):
        reset_episode(new_brain=False)
    elif(key == pygame.K_n):
        reset_episode(new_brain=True)
    elif(key == pygame.K_0):
        net_view["zoom"], net_view["pan"] = 1.0, [0.0, 0.0]
        net_view["yaw"], net_view["pitch"] = 0.0, 15.0


async def main():
    """웹(pygbag)용: 매 프레임 끝에 await asyncio.sleep(0)으로 브라우저에 제어를 돌려준다"""
    pygame.init()
    screen = pygame.display.set_mode((WIN_W, WIN_H))
    pygame.display.set_caption("neuron_project")
    clock = pygame.time.Clock()
    running = True

    last_sim = pygame.time.get_ticks() - FRAME_MS

    while(running):
        for event in pygame.event.get():
            # 웹용: 뉴런맵을 건드리는 조작이면 다시 그리게 표시 (휠, 클릭, 뉴런맵 위 마우스 이동, 키 입력)
            if(event.type in (pygame.MOUSEWHEEL, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.KEYDOWN)
               or (event.type == pygame.MOUSEMOTION and (AREA_NET.collidepoint(event.pos) or net_view["mouse"] is not None))):
                net_redraw["dirty"] = True

            if(event.type == pygame.QUIT):
                running = False
            elif(event.type == pygame.KEYDOWN):
                on_key(event.key)
            elif(event.type == pygame.MOUSEWHEEL):
                mouse = pygame.mouse.get_pos()

                if(AREA_NET.collidepoint(mouse)):
                    net_zoom(mouse, 1.2 ** event.y)
            elif(event.type == pygame.MOUSEBUTTONDOWN and AREA_NET.collidepoint(event.pos)):
                if(event.button == 1):
                    net_view["rotate"] = event.pos   # 왼쪽 드래그: 회전
                elif(event.button == 3):
                    net_view["drag"] = event.pos     # 오른쪽 드래그: 이동
            elif(event.type == pygame.MOUSEBUTTONUP):
                if(event.button == 1):
                    net_view["rotate"] = None
                elif(event.button == 3):
                    net_view["drag"] = None
            elif(event.type == pygame.MOUSEMOTION):
                net_view["mouse"] = event.pos if AREA_NET.collidepoint(event.pos) else None

                if(net_view["rotate"] is not None):
                    net_view["yaw"] = (net_view["yaw"] - (event.pos[0] - net_view["rotate"][0]) * NET_ROTATE_SPEED) % 360
                    net_view["pitch"] = max(-89, min(89, net_view["pitch"] + (event.pos[1] - net_view["rotate"][1]) * NET_ROTATE_SPEED))
                    net_view["rotate"] = event.pos

                if(net_view["drag"] is not None):
                    net_view["pan"][0] += event.pos[0] - net_view["drag"][0]
                    net_view["pan"][1] += event.pos[1] - net_view["drag"][1]
                    net_view["drag"] = event.pos

        # 시뮬레이션은 기존처럼 100ms마다 한 번, 화면은 초당 60번 갱신 (확대·이동이 부드럽게)
        now = pygame.time.get_ticks()

        if(now - last_sim >= FRAME_MS):
            sim_update()
            last_sim = now

        draw(screen)
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)   # 브라우저가 화면을 그리고 입력을 처리할 수 있게 양보

    brain.save("network.json")
    pygame.quit()
